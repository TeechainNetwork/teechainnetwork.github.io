#!/bin/bash
set -e

# Colour constants
bold=`tput bold`
green=`tput setaf 2`
red=`tput setaf 1`
reset=`tput sgr0`

ALICE_PORT=10001
BOB_PORT=10002

ALICE_LOG=test_scripts/testnet/test/alice.txt
BOB_LOG=test_scripts/testnet/test/bob.txt

if test -d bin; then cd bin; fi

echo "${bold}Mounting a RAM disk for server output in test directory!${reset}"
if mountpoint -q -- "test"; then
    sudo umount test
fi

rm -r test | true # in case this is the first time being run
mkdir test && sudo mount -t tmpfs -o size=5000m tmpfs test

# Source Intel Libraries
source /opt/intel/sgxsdk/environment

pushd ../../ # go to source directory
echo "${bold}Starting two ghost teechan enclaves...${reset}"

echo "${bold}Spawning enclave ALICE listening on port $ALICE_PORT in $ALICE_LOG ${reset}"
./teechan ghost -d -p $ALICE_PORT > $ALICE_LOG 2>&1 &
sleep 1

echo "${bold}Spawning enclave BOB listening on port $BOB_PORT in $BOB_LOG ${reset}"
./teechan ghost -d -p $BOB_PORT > $BOB_LOG 2>&1 &
sleep 1

echo -n "${red}Waiting until enclaves are initialized ...${reset}"
for u in alice bob; do 
    while [ "$(grep -a 'Enclave created' test_scripts/testnet/test/${u}.txt | wc -l)" -eq 0 ]; do
        sleep 0.1
        echo -n "."
    done
done

echo "."
echo "Enclaves created!"
echo ""

# Create primaries
./teechan primary -p $ALICE_PORT
./teechan primary -p $BOB_PORT

# Setup up primaries with number of deposits
./teechan setup_deposits 5 -p $ALICE_PORT
./teechan setup_deposits 3 -p $BOB_PORT

# Deposits made
./teechan deposits_made mmY6ijr6uLP3DdRFC4nwL23HSKsH2xgy74 1 5 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feA 0 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feA 1 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feA 2 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feA 3 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feA 4 1 -p $ALICE_PORT
./teechan deposits_made my6NJU1T6gL5f3TfmSPN4idUytdCQHTmsU 1 3 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feB 0 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feB 1 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feB 2 1  -p $BOB_PORT

# Create and establish a channel between Alice and Bob
./teechan create_channel -p $BOB_PORT &
sleep 1
./teechan create_channel -i -r 127.0.0.1:$BOB_PORT -p $ALICE_PORT # Initiator

sleep 2

# Extract the channel id for the channel created
CHANNEL_1=$(grep "Channel ID:" $ALICE_LOG | awk '{print $3}')

# Verified the setup transactions are in the blockchain
./teechan verify_deposits $CHANNEL_1 -p $BOB_PORT &
./teechan verify_deposits $CHANNEL_1 -p $ALICE_PORT

sleep 2

# Alice and Bob add deposits to their channels now
./teechan add_deposit $CHANNEL_1 0 -p $ALICE_PORT
./teechan add_deposit $CHANNEL_1 0 -p $BOB_PORT

# Alice check balance matches expected
./teechan balance $CHANNEL_1 -p $ALICE_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 1, remote balance is: 1"; then
    echo "Alice's balance check failed on channel setup!"; exit 1;
fi

# Send from Bob to Alice
./teechan send $CHANNEL_1 1 -p $BOB_PORT

# Alice check balance after
./teechan balance $CHANNEL_1 -p $ALICE_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 2, remote balance is: 0"; then
    echo "Alice's balance check failed after send!"; exit 1;
fi

# Send from Bob to Alice should fail. Bob check balance, shouldn't have changed
./teechan send $CHANNEL_1 1 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 2"; then
    echo "Bob's balance check failed!"; exit 1;
fi

# Add deposit from bob's side and check balance
./teechan add_deposit $CHANNEL_1 1 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 1, remote balance is: 2"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob added another deposit to his channel!"

# Send from Bob to Alice and check balance is back to zero
./teechan send $CHANNEL_1 1 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 3"; then
    echo "Bob's balance check failed!"; exit 1;
fi

# Send from Alice to Bob and check Bob's balance on Alice's side
./teechan send $CHANNEL_1 1 -p $ALICE_PORT
./teechan balance $CHANNEL_1 -p $ALICE_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 2, remote balance is: 1"; then
    echo "Alice's balance check failed!"; exit 1;
fi

# Bob remove deposit and check balance
./teechan remove_deposit $CHANNEL_1 1 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 2"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob removed the deposit from his channel!"

# Bob try to remove first deposit, should fail as insufficient funds
./teechan remove_deposit $CHANNEL_1 0 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 2"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob tried to remove the last deposit from his channel but it failed!"

# Alice send 2 to Bob and check balance from both sides
./teechan send $CHANNEL_1 2 -p $ALICE_PORT
./teechan balance $CHANNEL_1 -p $ALICE_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 0, remote balance is: 2"; then
    echo "Alice's balance check failed!"; exit 1;
fi
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 2, remote balance is: 0"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Alice sent 2 to Bob!"

# Bob now remove last deposit from channel
./teechan remove_deposit $CHANNEL_1 0 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 1, remote balance is: 0"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob removed his last deposit from the channel!"

# Bob now send 1 to alice
./teechan send $CHANNEL_1 1 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 1"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob sent 1 to Alice!"

# Alice removed last deposit from channel
./teechan remove_deposit $CHANNEL_1 0 -p $ALICE_PORT
./teechan balance $CHANNEL_1 -p $ALICE_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 0, remote balance is: 0"; then
    echo "Alice's balance check failed!"; exit 1;
fi
echo "Alice removed her last deposit from the channel!"

# Bob now send 1 to alice
./teechan send $CHANNEL_1 1 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 0"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob tried to send 1 to alice, but it didnt work!"

# Add all the deposits to the channel (both sides)
./teechan add_deposit $CHANNEL_1 0 -p $ALICE_PORT
./teechan add_deposit $CHANNEL_1 1 -p $ALICE_PORT
./teechan add_deposit $CHANNEL_1 2 -p $ALICE_PORT
./teechan add_deposit $CHANNEL_1 3 -p $ALICE_PORT
./teechan add_deposit $CHANNEL_1 4 -p $ALICE_PORT

./teechan add_deposit $CHANNEL_1 0 -p $BOB_PORT
./teechan add_deposit $CHANNEL_1 1 -p $BOB_PORT
./teechan add_deposit $CHANNEL_1 2 -p $BOB_PORT

./teechan balance $CHANNEL_1 -p $ALICE_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 5, remote balance is: 3"; then
    echo "Alice's balance check failed!"; exit 1;
fi
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 3, remote balance is: 5"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "All deposits added to the channel!"

# Bob now send 3 to alice
./teechan send $CHANNEL_1 3 -p $BOB_PORT
./teechan balance $CHANNEL_1 -p $BOB_PORT
if ! tail -n 2 $BOB_LOG | grep -q "My balance is: 0, remote balance is: 8"; then
    echo "Bob's balance check failed!"; exit 1;
fi
echo "Bob sent all 3 to Alice!"

# Settle and shutdown
./teechan settle_channel $CHANNEL_1 -p $ALICE_PORT

# Alice decides to get her unused deposits out (there are no used deposits!)
./teechan shutdown -p $ALICE_PORT

popd # return to bin directory

./kill.sh
echo "${bold}Looks like the test passed!${reset}"
