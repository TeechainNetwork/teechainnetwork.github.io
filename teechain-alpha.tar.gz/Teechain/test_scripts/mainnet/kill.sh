#!/bin/bash

echo "Killing teechan processes"

while [ "$(ps aux | grep teechan | grep ghost | wc -l)" -ne 0 ]; do
     kill -9 $(ps aux | grep teechan | grep ghost | awk '{print $2}')
    sleep 0.1
done
