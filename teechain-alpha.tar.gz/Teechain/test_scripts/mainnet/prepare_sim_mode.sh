#!/bin/bash
set -e

# Colour constants
bold=`tput bold`
green=`tput setaf 2`
red=`tput setaf 1`
reset=`tput sgr0`

echo "${bold}Moving the mainnet simulation binaries to the root of the directory to run scripts...!${reset}"
cp ../../binaries/mainnet/simulation/* ../../
echo "${bold}You can start running the mainnet scripts!${reset}"
