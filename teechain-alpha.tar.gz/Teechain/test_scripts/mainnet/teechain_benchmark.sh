#!/bin/bash
set -e

# Colour constants
bold=`tput bold`
green=`tput setaf 2`
red=`tput setaf 1`
reset=`tput sgr0`

ALICE_PORT=10001
BOB_PORT=10002

ALICE_LOG=test_scripts/mainnet/test/alice.txt
BOB_LOG=test_scripts/mainnet/test/bob.txt

if test -d bin; then cd bin; fi

echo "${bold}Mounting a RAM disk for server output in test directory!${reset}"
if mountpoint -q -- "test"; then
    sudo umount test
fi

rm -r test | true # in case this is the first time being run
mkdir test && sudo mount -t tmpfs -o size=5000m tmpfs test

# Source Intel Libraries
source /opt/intel/sgxsdk/environment

pushd ../../ # go to source directory
echo "${bold}Starting two ghost teechan enclaves...${reset}"

echo "${bold}Spawning enclave ALICE listening on port $ALICE_PORT in $ALICE_LOG ${reset}"
./teechan ghost -b -p $ALICE_PORT > $ALICE_LOG 2>&1 &
sleep 1

echo "${bold}Spawning enclave BOB listening on port $BOB_PORT in $BOB_LOG ${reset}"
./teechan ghost -b -p $BOB_PORT > $BOB_LOG 2>&1 &
sleep 1

echo -n "${red}Waiting until enclaves are initialized ...!${reset}"
for u in alice bob; do 
    while [ "$(grep -a 'Enclave created' test_scripts/mainnet/test/${u}.txt | wc -l)" -eq 0 ]; do
        sleep 0.1
        echo -n "."
    done
done

echo "."
echo "Enclaves created!"
echo ""

# Create primaries
./teechan primary -p $ALICE_PORT
./teechan primary -p $BOB_PORT

# Setup up primaries with number of deposits
./teechan setup_deposits 1 -p $ALICE_PORT
./teechan setup_deposits 1 -p $BOB_PORT

# Deposits made
./teechan deposits_made 1PxpP8fCsdjVrS187fP2byc5uYap3fA7j2 1 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feA 0 1000002 -p $ALICE_PORT
./teechan deposits_made 1NqY7EC7Y5oZSMHos3CJxv1Z69BdkLZvWy 1 1 edec34c9bb3a4395cd8d1e9300725f537235d8a058fc6a7ae519003b64fd0feB 0 1 -p $BOB_PORT

# Create and establish a channel between Alice and Bob
./teechan create_channel -p $BOB_PORT &
sleep 1
./teechan create_channel -i -r 127.0.0.1:$BOB_PORT -p $ALICE_PORT # Initiator

sleep 2

# Extract the channel id for the channel created
CHANNEL_1=$(grep "Channel ID:" $BOB_LOG | awk '{print $3}')

# Verified the setup transactions are in the blockchain
./teechan verify_deposits $CHANNEL_1 -p $BOB_PORT &
./teechan verify_deposits $CHANNEL_1 -p $ALICE_PORT

sleep 2

# Alice and Bob add deposits to their channels now
./teechan add_deposit $CHANNEL_1 0 -p $ALICE_PORT
./teechan add_deposit $CHANNEL_1 0 -p $BOB_PORT

# Alice check balance matches expected
./teechan balance $CHANNEL_1 -p $ALICE_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 1000002, remote balance is: 1"; then
    echo "Alice's balance check failed on channel setup!"; exit 1;
fi

echo "Alice is sending 200,000 satoshi, 1 at a time to Bob!"
./teechan benchmark -b $CHANNEL_1 200000 -p $ALICE_PORT

# Alice check balance after
./teechan balance $CHANNEL_1 -p $ALICE_PORT
if ! tail -n 2 $ALICE_LOG | grep -q "My balance is: 800002, remote balance is: 200001"; then
    echo "Alice's balance check failed after send!"; exit 1;
fi

# Alice decides to settle channel 1 (no unused deposits)
./teechan shutdown -p $ALICE_PORT

popd # return to bin directory

./kill.sh
echo "${bold}Looks like the test passed!${reset}"
